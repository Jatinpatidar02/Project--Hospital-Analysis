<?php

$hostname="localhost";
$dbname="hospital";
$username="root";
$password="";
try{
$conn=new PDO("mysql:host=$hostname;dbname=$dbname",$username,$password);

}
catch(Exception $e)
{
echo $e;
}

// $connection=mysqli_connect("localhost","root","","hospital");
// if($connection)
// {
// echo "connected";
// }

// else
// {
// 	echo "error";
// }
// if($conn)
// {
// 	echo"connected";

// }
// else{
// 	echo"connection failed";
// }






?>
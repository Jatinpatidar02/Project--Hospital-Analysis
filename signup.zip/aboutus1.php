<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.js">
  <title></title>
  <style type="text/css"> .navupdate{
    box-shadow: 1px 10px 20px 2px grey;
    height:  100px;
  }
.navupdate a{
    color: #80d4ff;
font-weight: bold;
  }
  .navupdate a.active{
    background:  #80d4ff;

  }
  .navupdate a:hover{
    background:  #80d4ff;
    color: white;
    font-weight: bold;
    z-index: 1;

  }

body{

  
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
}

  </style>
</head>
<body >
  

<nav class="navbar navbar-expand-lg navbar-light bg-light navupdate " > 
 
  <a href="homepage.php" class="mb-0" style="background: transparent;"><img src="img/hna.jpg" height="50" width="80" style="margin-left: 105px; margin-top:15px" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      
                <li><a href="homepage.php" class="nav-link"style="margin-right: 20px" ><strong>HOME</strong></a></li>
                <li><a href="aboutus1.php" class="nav-link active"style="margin-right: 20px"> <strong>ABOUT US</strong></a></li>
                <li><a href="customersupport.php" class="nav-link" style="margin-right: 100px"><strong>CUSTOMER SUPPORT</strong></a></li>
    </ul>
  </div>

</nav>

<div class="container-fluid content" class="jumbotron" style="padding-left:  800px;background: transparent;filter: brightness(.5); ">
 
<p style="text-align: center;font-weight: bolder;color:black;font-size: 20px;font-family: courier;margin-top: 30px;padding-bottom: 200px;padding-top: 40px;text-transform: uppercase; ">The H/A i.e. Hospital Analysis is platform where every individual can access information about hospitals regarding their disease and able to compare hospitals regarding paycharges of each hospital and specialist doctor according to individual's healthcare need.
                          !!!Choose Best !!!!  </p>


</div>








</body>
</html> 

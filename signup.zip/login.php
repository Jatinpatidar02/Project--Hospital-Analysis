

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.js">


<?php
include"navbar.php";


?>


	<title></title>
</head>
<body>

<?php
session_start();

    include"connect.php";
if(isset($_POST['hospitallogin']))
  { $sql='select * from hospital_relation where hosuser=? and hospass=?';
    
    $stmt=$conn->prepare($sql);
    $stmt->execute([$_POST['hospitalname'],$_POST['hospass']]);
    $row=$stmt->fetchAll(PDO::FETCH_ASSOC);

    $count=$stmt->rowCount();

    if($count>0)
    {
foreach($row as $rows)
{
    	$_SESSION['hosname']=$rows['hosname'];
    	header('Location:hospitalpage.php');
    }

}
else
{
	echo "wrong username password";
}




}

if(isset($_POST['userlogin']))
  { $sql='select * from user_relation where username=? and loginpass=?';
    
    $stmt=$conn->prepare($sql);
    $stmt->execute([$_POST['username'],$_POST['userpass']]);
    $row=$stmt->fetchAll(PDO::FETCH_ASSOC);

    $count=$stmt->rowCount();

    if($count>0)
    {
foreach($row as $rows)
{
    	$_SESSION['userid']=$rows['userid'];
    	header('Location:comparison.php');
    }

}
else
{
	echo "wrong username password";
}




}



    ?>




	<form method="post" >
		<div class="container">
			<div class="row">
				
				<div class="col-lg-6">
					
  <h4> <button style="margin-left: 200px; margin-top: 50px;margin-bottom: 40px; padding: 3px 3px 3px 3px; background: #3399ff; color: black; border-color: black; border-radius: 0.5px; border: 1px solid #3399ff;
  padding: 3px; box-shadow: 8px 6px;">User Login </button></h4>

  <div class="form-group">
    <label >Username</label>
    <input type="text" class="form-control" name="username" >
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="userpass">
  </div>
  
  <button type="submit" class="btn btn-primary" name="userlogin">Submit</button>


				</div>

				<div class="col-lg-6">
					<h4> <button style="margin-left: 200px; margin-top: 50px;margin-bottom: 40px; padding: 3px 3px 3px 3px; background: #3399ff; color: black; border-color: black; border-radius: 0.5px; border: 1px solid #3399ff;
             padding: 3px; box-shadow: 8px 6px;">Hospital Login </button></h4>

					<div class="form-group">
    <label >Username</label>
    <input type="text" class="form-control" name="hospitalname">
    
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="hospass">
  </div>
  
  <button type="submit" class="btn btn-primary" name="hospitallogin">Submit</button>




				</div>



			</div>
		</div>


</form>



</body>
</html>
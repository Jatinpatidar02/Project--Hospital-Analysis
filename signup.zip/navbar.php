<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

  <title></title>
  <style type="text/css"> 
    
.navupdate a{
    color: #80d4ff;
font-weight: bold;
  }
  .navupdate a.active{
    background:  #80d4ff;

  }
  .navupdate a:hover{
    background:  #80d4ff;
    color: white;
    font-weight: bold;
    z-index: 1;

  }



  </style>
</head>
<body>
  

<nav class="navbar navbar-expand-lg navbar-light bg-light navupdate " > 
 
  <a href="homepage.php" class="mb-0"><img src="img/hna.jpg" height="50" width="80" style="margin-left: 105px; margin-top:15px" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      
                <li><a href="homepage.php" class="nav-link"style="margin-right: 20px" ><strong>HOME</strong></a></li>
                <li><a href="aboutus1.php" class="nav-link"style="margin-right: 20px"> <strong>ABOUT US</strong></a></li>
                <li><a href="customersupport.php" class="nav-link" style="margin-right: 100px"><strong>CUSTOMER SUPPORT</strong></a></li>
    </ul>
  </div>

</nav>







</body>
</html> 

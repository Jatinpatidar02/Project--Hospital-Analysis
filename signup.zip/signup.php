<!DOCTYPE html>
<html>
	<head>
		<title></title>
			<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.js">

<?php

include"navbar.php";
?>


	</head>
	<body>
<?php
session_start();

    include"connect.php";
if(isset($_POST['usersignup']))
  { $sql='insert into user_relation (mobileno,dob,address,username,loginpass) values(?,?,?,?,?)';
    
    $stmt=$conn->prepare($sql);
    if($stmt->execute([$_POST['usernum'],$_POST['userdob'],$_POST['useradd'],$_POST['username'],$_POST['userpass']]))
    {
    echo "Signedup successfully";
    header('Location: login.php');
}
else
{
	echo "signuped failed";
}



}

		?>
		<form method="post" >
			<div class="container">
				<div class="row">
					
					<div class="col-lg-12">
						
						<h4><button style="margin-left: 500px; margin-top: 50px;margin-bottom: 40px; padding: 3px 3px 3px 3px; background: #3399ff; color: black; border-color: black; border-radius: 0.5px; border: 1px solid #3399ff;
                             padding: 3px; box-shadow: 8px 6px;">User Singup </button></h4>
						<div class="form-group">
							<label >Username</label>
							<input type="text" class="form-control" name="username" required >
							
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Password</label>
							<input type="password" class="form-control" name="userpass" required>
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Mobile Number</label>
							<input type="text" class="form-control" name="usernum" required>
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Date of Birth</label>
							<input type="date" class="form-control" name="userdob" required>
						</div>
						<div class="form-group">
							<label for="exampleInputPassword1">Address</label>
							<input type="text" class="form-control" name="useradd" required>
						</div>
						
						<button type="submit" class="btn btn-primary" name="usersignup">Submit</button>
					</div>
				
				</div>
			</div>
		</form>
	</body>
</html>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.js">
  <title></title>
  <style type="text/css"> .navupdate{



  </style>
</head>
<body>
  

<nav class="navbar navbar-expand-lg navbar-light bg-light navupdate " > 
 
  <a href="index.html" class="mb-0"><img src="img/hna.jpg" height="50" width="80" style="margin-left: 105px; margin-top:15px" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      
                <li><a href="#" class="nav-link"style="margin-right: 20px" ><strong>HOME</strong></a></li>
                <li><a href="#" class="nav-link"style="margin-right: 20px"> <strong>ABOUT US</strong></a></li>
                <li><a href="#" class="nav-link" style="margin-right: 100px"><strong>CUSTOMER SUPPORT</strong></a></li>
    </ul>
  </div>

</nav>







</body>
</html> 

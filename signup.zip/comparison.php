<?php
include 'connect.php';
?>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Pricing Table</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <style>
    
    .navupdate a{
    color: #80d4ff;
    font-weight: bold;
    }
    .navupdate a.active{
    background:  #80d4ff;
    }
    .navupdate a:hover{
    background:  #80d4ff;
    color: white;
    font-weight: bold;
    z-index: 1;
    }
    .diseaselist{
    text-decoration: none;
    font-weight: bold;
    font-size: 13px;
    padding-left:   7px;
    padding-top:  7px;
    padding-bottom:  7px;
    }
    .diseaselist:hover{
    text-decoration: none;
    color: white;
    font-weight: bold;
    background: seagreen;
    box-shadow: 0px 0px 6px 0px grey;
    }
    .inputs
    {
    background: transparent;
    color: white;
    border-top: 0px;
    border-right:  0px;
    border-bottom:  1px solid white;
    border-left: 0px ;
    }
    label{
    font-size: 20px;
    }
    select{
    font-size: 15px;
    }
    p{
    font-size: 15px;
    }
    .doctorslist{
    
    font-weight: bold;
    color: white;
    font-size: 10px;
    background: transparent;
    
    }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light navupdate " >
      
      <a href="homepage.php." class="mb-0"><img src="img/hna.jpg" height="50" width="80" style="margin-left: 105px; margin-top:15px" ></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          
          <li><a href="#" class="nav-link"style="margin-right: 20px;font-size:15px" ><strong>HOME</strong></a></li>
          <li><a href="#" class="nav-link"style="margin-right: 20px;font-size:15px"> <strong>ABOUT US</strong></a></li>
          <li><a href="#" class="nav-link" style="margin-right: 100px;font-size:15px"><strong>CUSTOMER SUPPORT</strong></a></li>
          <li><a data-target="#exampleModalCenter" data-toggle="modal"
           href="" class="nav-link" style="margin-right: 100px;font-size:15px"><strong>Logout</strong></a></li>
        </ul>
      </div>
    </nav>



    <!-- Button trigger modal -->
   <?php 
session_start();
if(empty(isset($_SESSION['userid']))==true)
{
  header('Location:login.php');
}
    if(isset($_POST['logout']))
    { 
      

      $sql='insert into hos_review values(?,?,?)';
     $stmt=$conn->prepare($sql);
   $stmt->execute([$_POST['hospital1'],$_SESSION['userid'],$_POST['feedback']]);
   header('Location:userlogout.php');

    }



 ?>






<form method="post"  >
<div class="modal fade" id="exampleModalCenter" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="text-align: center;">
        <h5 class="modal-title" id="exampleModalCenterTitle">Feedback</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label>Hospital List</label>
                          <select class="container" name="hospital1" style="color: black">
                            <?php
                            $sql='select * from hospital_relation';
                            $stmt=$conn->prepare($sql);
                            $stmt->execute([]);
                            $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                            $count=$stmt->rowCount();
                            if($count>0)
                            {
                            foreach ($row as $rows) {
                            
                            ?>
                            
                            <option ><?= $rows['hosname'] ?></option>
                            <?php
                            
                            }} ?>
                          </select>
                            <input type="radio" name="feedback" value="never visited"style="margin-right: 8px" >Never Visited Any Hospital<br>

                          <p style="font-weight: bolder; margin-top: 5px"> What You Disliked The Most</p>
                          <input type="radio" name="feedback" value="Infrastructure" style="margin-right: 8px">Infrastructure<br>
                          <input type="radio" name="feedback" value="Availability" style="margin-right: 8px">Doctors Availability<br>
                          <input type="radio" name="feedback" value="Behaviour"style="margin-right: 8px">Staff Behaviour<br>
                          <input type="radio" name="feedback" value="Facility"style="margin-right: 8px">Medical Facility<br>
                          <input type="radio" name="feedback" value="Charges Applied"style="margin-right: 8px">Charges Applied<br>
                        
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" name="logout">Submit and Logout</button>
      </div>
    </div>
  </div>
</div>





    <!-- Button trigger modal -->
    <!-- Button trigger modal -->
    <!-- Modal -->
    <!-- Modal -->
    <section>
      <div class="container-fluid">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-3" style="box-shadow:1px 2px 20px 2px grey ;padding: 30px;">
              <h3 class="btn btn-info container" style="text-align: center;font-weight: bolder;font-size: 20px;color: white;margin-bottom:  30px">DISEASES </h3>
              <?php
              
              
              $sql="select * from disease_relation";
              $stmt=$conn->prepare($sql);
              $stmt->execute([]);
              $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
              $count=$stmt->rowCount();
              if($count>0)
              {
              foreach ($row as $rows) {
              
              
              
              ?>
              <a style="font-size: 15px" class="diseaselist" id="diseasename1" href="comparison.php?value=<?= $rows['diseasename'] ?>"><?php echo $rows['diseasename']; ?><br><br></a>
              <?php }
              } ?>
            </div>
            <!-- END Col one -->
            <div class="col-sm-4" >
              <div class="card text-center" style="max-width: 500px;height: auto">
                <div class="title">
                  
                  <!-- <i> <img src="img/hospital.jpg" class="rounded-circle" width="70" height="70" style="text-align: center;border: 2px solid white"></i> -->
                  <h2></h2>
                </div>
                <div class="price">
                  
                </div>
                <div class="option">
                  <ul>
                    <label>Disease Name</label>
                    <li>
                      <input class="inputs"  type="text" placeholder="Disease name" name="diseasename" id="diseasecard1" value="<?= isset($_GET['value'])?$_GET['value']: "";?>" /> </li>

                      
                        <label>Hospital List</label>
                        <select class="container" name="selectedhospital"  style="color: black">
                          <?php
                          $sql='select hosname from hospital_relation where hid in(select hid from hos_disease where diseaseid in (select diseaseid from disease_relation where diseasename=?))';
                          $stmt=$conn->prepare($sql);
                          $stmt->execute([$_GET['value']]);
                          $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                          $count=$stmt->rowCount();
                          if($count>0)
                          {
                          foreach ($row as $rows) {
                          
                          ?>
                          
                          <option><?= $rows['hosname'] ?></option>
                          
                          <?php
                          
                          }
                          }
                          ?>
                        </select>
                        
                        <?php
                        if(isset($_POST['ok']))
                        {
                        $doctorbutton='';
                        
                        $sql='select * from hospital_relation where hosname=? ';
                        $stmt=$conn->prepare($sql);
                        $stmt->execute([$_POST['selectedhospital']]);
                        $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                        $counts=$stmt->rowCount();
                        if($counts>0)
                        {
                        foreach  ($row as $rows) {
                        ?>
                        <p style="font-weight: bold;margin-top: 15px"><span style="color: white;font-weight: bolder;font-size: 20px">Hospital Name :</span> <br><?= $rows['hosname'] ?></p>

                        <i> <img src="<?= $rows['img']; ?>"  width="250" height="150" style="text-align: center;border: 2px solid white;margin-top: 10px"></i>
                        <p style="font-weight: bold;margin-top: 15px"><span style="color: white;font-weight: bolder;font-size: 20px;">Address :</span> <br><?= $rows['hosaddress'] ?></p>
                        <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Contact No. :</span><br><?= $rows['contactno'] ?></p>
                        <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Rating :</span><br><?= $rows['rating'] ?></p>
                        <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Food Availability. :</span><br><?= $rows['food'] ?></p>
                        <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Infrastructure : </span><br><?= $rows['infra'] ; ?></p>
                        <?php }
                        $query='select * from cures_relation where diseaseid in (select diseaseid from disease_relation where diseasename =?) and hid in(select hid from hospital_relation where hosname=?) ';
                        $stmts=$conn->prepare($query);
                        $stmts->execute([$_GET['value'],$_POST['selectedhospital']]);
                        $rows=$stmts->fetchAll(PDO::FETCH_ASSOC);
                        $counts=$stmts->rowCount();
                        if($counts>0)
                        {
                        foreach ($rows as $rowss) {
                        
                        ?>
                        <p style="font-weight: bold;text-align: center;"><span style="color: white;font-weight: bolder;font-size: 20px">Paycharges </span><br>Approx <?=$rowss['paycharges']?> /-</p>
                        
                        <?php
                        }}
                        }
                        ?>
                        <p style="font-weight: bold;text-align: center;"><span style="color: white;font-weight: bolder;font-size: 20px">Doctors </span><br></p>
                        <?php
                        $sql='select * from dr_relation where drid in (select drid from hos_disease where diseaseid in(select diseaseid from disease_relation where diseasename =?) and hid in(select hid from hospital_relation where hosname=?)  )';
                        
                        $stmt=$conn->prepare($sql);
                        $stmt->execute([$_GET['value'],$_POST['selectedhospital']]);
                        $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                        $count=$stmt->rowCount();
                        if($count>0)
                        {
                        foreach ($row as $rows) {
                        $doctorbutton=$rows['drid'];
                        ?>
                        <!--  -->
                        <button type="button" class="btn-info btn " data-target="#collapse" data-toggle="collapse" aria-expanded="false" style="margin-bottom: 10px"><?= $rows['drname']; ?> </button><br>
                        <div class="collapse" style="margin-bottom: 10px" id="collapse" >
                          <div class="card card-body container" style="width: 100%;height: auto;background: transparent;">
                            <p style="color: black;float: left;"><span style="color: white;font-weight: bold;font-size: 15px;font-weight: bolder" > Specialization     :</span><?= $rows['specialization']; ?> </p>
                            <p style="color: black;float: left;"><span style="color: white;font-weight: bold;font-size: 15px;font-weight: bolder" >Year of experience :</span> <?= $rows['yrofexperience']; ?> </p>
                            <p style="color: black;float: left;"><span style="color: white;font-weight: bold;font-size: 15px;font-weight: bolder">Degree             :</span><?= $rows['degree']; ?> </p>
                          </div>
                        </div>
                        
                        <?php }
                        }
                        }
                        ?>
                        
                        
                        
                        
                        
                        <li>  </li>
                        <li>   </li>
                      </ul>
                    </div>
                    
                  </div>
                </div>
                <div class="colo-sm-1">
                  <input style="margin-top: 280px;font-size: 12px;border: 1px solid white; background: linear-gradient(-45deg,#ffec61,#f321d7);;color: white;font-weight: bolder;" type="submit" class="btn container" value="Compare" name="ok">
                </div>
                <!-- END Col two -->
                <div class="col-sm-4">
                  <div class="card text-center" style="max-width: 500px;height: auto; background: linear-gradient(-45deg,#24ff72,#9a4eff);">
                    <div class="title">
                      
                      <h2></h2>
                    </div>
                    <div class="price">
                      
                    </div>
                    <div class="option">
                      <ul>
                        
                        <label>Disease Name</label>
                        <li>
                          <input class="inputs"  type="text" placeholder="Disease name" name="diseasename" id="diseasecard2" value="<?= isset($_GET['value'])?$_GET['value']: "";?>" /> </li>
                          
                          <label>Hospital List</label>
                          <select class="container" name="selectedhospital1" style="color: black">
                            <?php
                            $sql='select hosname from hospital_relation where hid in(select hid from hos_disease where diseaseid in (select diseaseid from disease_relation where diseasename=?))';
                            $stmt=$conn->prepare($sql);
                            $stmt->execute([$_GET['value']]);
                            $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                            $count=$stmt->rowCount();
                            if($count>0)
                            {
                            foreach ($row as $rows) {
                            
                            ?>
                            
                            <option ><?= $rows['hosname'] ?></option>
                            <?php
                            
                            }} ?>
                          </select>
                          <?php
                          $docname='';
                          if(isset($_POST['ok']))
                          {
                          $sql='select * from hospital_relation where hosname=? ';
                          $stmt=$conn->prepare($sql);
                          $stmt->execute([$_POST['selectedhospital1']]);
                          $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                          $counts=$stmt->rowCount();
                          if($counts>0)
                          {
                          foreach ($row as $rows) {
                          
                          ?>
                          <i> <img src="<?= $rows['img']; ?>" width="250" height="150" style="text-align: center;border: 2px solid white;margin-top: 10px"></i>
                          <p style="font-weight: bold;margin-top: 20px"><span style="color: white;font-weight: bolder;font-size: 20px">Address :</span> <br><?= $rows['hosaddress'] ?></p>
                          <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Contact No. :</span><br> <?= $rows['contactno'] ?></p>
                          <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Rating :</span><br><?= $rows['rating'] ?></p>
                          <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Food Availability. :</span><br><?= $rows['food'] ?></p>
                          <p style="font-weight: bold;"><span style="color: white;font-weight: bolder;font-size: 20px">Infrastructure : </span><br><?= $rows['infra'] ?></p>
                          
                          
                          
                          <?php }
                          }
                          $query='select * from cures_relation where diseaseid in (select diseaseid from disease_relation where diseasename =?) and hid in(select hid from hospital_relation where hosname=?) ';
                          $stmts=$conn->prepare($query);
                          $stmts->execute([$_GET['value'],$_POST['selectedhospital1']]);
                          $rows=$stmts->fetchAll(PDO::FETCH_ASSOC);
                          $counts=$stmts->rowCount();
                          if($counts>0)
                          {
                          foreach ($rows as $rowss) {
                          
                          ?>
                          <p style="font-weight: bold;text-align: center;"><span style="color: white;font-weight: bolder;font-size: 20px">Paycharges </span><br><?=$rowss['paycharges']?></p>
                          
                          <?php
                          }}
                          ?>
                          <p style="font-weight: bold;text-align: center;"><span style="color: white;font-weight: bolder;font-size: 20px">Doctors </span><br></p>
                          <?php
                          $sql='select * from dr_relation where drid in (select drid from hos_disease where diseaseid in(select diseaseid from disease_relation where diseasename =?) and hid in(select hid from hospital_relation where hosname=?)  )';
                          
                          $stmt=$conn->prepare($sql);
                          $stmt->execute([$_GET['value'],$_POST['selectedhospital1']]);
                          $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
                          $count=$stmt->rowCount();
                          if($count>0)
                          {
                          foreach ($row as $rows) {
                          $doctorbutton=$rows['drid'];
                          ?>
                          
                          <!--  -->
                          <button type="button" class="btn-info btn " data-target="#collapsee" data-toggle="collapse" aria-expanded="false" style="margin-bottom: 10px"><?= $rows['drname']; ?> </button><br>
                          <div class="collapse" style="margin-bottom: 10px" id="collapsee" >
                            <div class="card card-body container" style="width: 100%;height: auto;background: transparent;">
                              <p style="color: black;float: left;"><span style="color: white;font-size: 15px;font-weight: bolder" > Specialization     :</span><?= $rows['specialization']; ?> </p>
                              <p style="color: black;float: left;"><span style="color: white;font-size: 15px;font-weight: bolder" >Year of experience :</span> <?= $rows['yrofexperience']; ?> </p>
                              <p style="color: black;float: left;"><span style="color: white;font-size: 15px;font-weight: bolder">Degree             :</span><?= $rows['degree']; ?> </p>
                            </div>
                          </div>
                          <?php     }
                          ?>
                          
                          <?php }
                          }
                          ?>
                          
                        </form>
                        
                      </ul>
                    </div>
                    
                  </div>
                  
                </div>
                <!-- END Col three -->
              </div>
            </div>
            
          </div>
          
        </section>
        <!-- Button trigger modal -->
      </body>
    </html>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<style type="text/css"> 

body{


	background: linear-gradient(-45deg,#ffec61,#f321d7);
}	

	
    
.navupdate a{
    color: #80d4ff;
font-weight: bold;
  }
  .navupdate a.active{
    background:  #80d4ff;

  }
  .navupdate a:hover{
    background:  #80d4ff;
    color: white;
    font-weight: bold;
    z-index: 1;

  }



  </style>
</head>
<body >


<nav class="navbar navbar-expand-lg navbar-light bg-light navupdate " > 
 
  <a href="index.html" class="mb-0"><img src="img/hna.jpg" height="50" width="80" style="margin-left: 105px; margin-top:15px" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ml-auto">
      
                <li><a href="#" class="nav-link"style="margin-right: 20px" ><strong>HOME</strong></a></li>
                <li><a href="#" class="nav-link"style="margin-right: 20px"> <strong>ABOUT US</strong></a></li>
                <li><a href="#" class="nav-link" style="margin-right: 100px"><strong>CUSTOMER SUPPORT</strong></a></li>
                <li><a href="userlogout.php" class="nav-link" style="margin-right: 100px"><strong>LOGOUT </strong></a></li>
    </ul>
  </div>

</nav>
<?php
include"connect.php";
session_start();



if(empty(isset($_SESSION['hosname']))==true)
{
  header('Location:login.php');
}
   








$sql='select * from hos_review where hosname=?';

 $stmt=$conn->prepare($sql);
    $stmt->execute([$_SESSION['hosname']]);
    $row=$stmt->fetchAll(PDO::FETCH_ASSOC);

    $count=$stmt->rowCount();

    if($count>0)
    {$c1='0';
$c2='0';
$c3='0';
$c4='0';
$c5='0';
foreach($row as $rows)
{
    	$feedback=$rows['feedback'];
    	if($feedback=='Infrastructure')
    	{
    		$c1++;
    	}
    	if($feedback=='Availability')
    	{
    		$c2++;
    	}
    	if($feedback=='Facility')
    	{
    		$c3++;
    	}
    	if($feedback=='Behaviour')
    	{
    		$c4++;
    	}
    	if($feedback=='Charges Applied')
    	{
    		$c5++;
    	}
    	
    		
    }
   
    	?>





<table class="table table-hover table-dark" >
  <thead>
    <tr>
              <th>       </th>
      <th scope="col">Infrastructure</th>
      <th scope="col">Doctors Availability</th>
      <th scope="col">Staff Behaviour</th>
      <th scope="col">Medical Facility</th>
      <th scope="col">Charges Applied</th>

    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">No. of User Dislike</th>

		<td><?= $c1; ?></td>
		<td><?= $c2; ?></td>
		<td><?= $c4; ?></td>
		<td><?= $c3; ?></td>
		<td><?= $c5; ?></td>
   
    </tr>
    
  </tbody>
</table>








    	<?php
}

?>



</body>
</html>